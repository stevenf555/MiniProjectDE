/*Tulis query untuk mendapatkan jumlah customer tiap bulan yang melakukan order pada tahun 1997.*/
SELECT MONTH(OrderDate) as 'Month', COUNT(CUSTOMERID) as CustomerCount FROM Orders WHERE YEAR(OrderDate) = 1997 GROUP BY MONTH(OrderDate)

/*Tulis query untuk mendapatkan nama employee yang termasuk Sales Representative.*/

SELECT CONCAT(FirstName,' ',LastName) as 'Customer Name' FROM Employees WHERE Title LIKE '%Sales Representative%'

/*Tulis query untuk mendapatkan top 5 nama produk yang quantitynya paling banyak diorder pada bulan Januari 1997.*/

SELECT TOP 5 ProductName, Quantity FROM Orders Join [Order Details] ON Orders.OrderID = [Order Details].OrderID JOIN Products ON [Order Details].ProductID = Products.ProductID WHERE YEAR(OrderDate) = 1997  AND MONTH(OrderDate) = 1  ORDER BY Quantity DESC 

/*Tulis query untuk mendapatkan nama company yang melakukan order Chai pada bulan Juni 1997.*/

SELECT CompanyName FROM Orders Join [Order Details] ON Orders.OrderID = [Order Details].OrderID JOIN Products ON [Order Details].ProductID = Products.ProductID JOIN Suppliers ON Products.SupplierID = Suppliers.SupplierID WHERE YEAR(OrderDate) = 1997  AND MONTH(OrderDate) = 6 AND ProductName LIKE '%Chai%'

/*Tulis query untuk mendapatkan jumlah OrderID yang pernah melakukan pembelian (unit_price dikali quantity) <=100, 100<x<=250, 250<x<=500, dan >500.*/

SELECT 
	COUNT(CASE WHEN UnitPrice * Quantity <= 100 THEN 1 END) as 'Less than 100',
	COUNT(CASE WHEN UnitPrice * Quantity > 100 AND UnitPrice * Quantity <= 250  THEN 1 END) as 'More than 100 and Less than 250',
	COUNT(CASE WHEN UnitPrice * Quantity > 250 AND UnitPrice * Quantity <= 500  THEN 1 END) as 'More than 250 and Less than 500',
	COUNT(CASE WHEN UnitPrice * Quantity > 500 THEN 1 END) as 'More than 500'
FROM Orders Join [Order Details] ON Orders.OrderID = [Order Details].OrderID 

SELECT * FROM [Order Details]

/*Tulis query untuk mendapatkan Company name pada tabel customer yang melakukan pembelian di atas 500 pada tahun 1997.*/

SELECT CompanyName FROM Orders JOIN [Order Details] ON Orders.OrderID = [Order Details].OrderID JOIN Customers ON Orders.CustomerID = Customers.CustomerID WHERE YEAR(OrderDate) = 1997 GROUP BY CompanyName HAVING SUM(([Order Details].UnitPrice * [Order Details].Quantity)) > 500

/*Tulis query untuk mendapatkan nama produk yang merupakan Top 5 sales tertinggi tiap bulan di tahun 1997.*/

SELECT TOP 5 ProductName FROM Orders JOIN [Order Details] ON Orders.OrderID = [Order Details].OrderID JOIN Customers ON Orders.CustomerID = Customers.CustomerID JOIN Products ON [Order Details].ProductID = Products.ProductID WHERE YEAR(OrderDate) = 1997 GROUP BY ProductName ORDER BY SUM([Order Details].UnitPrice * [Order Details].Quantity) DESC

/*Buatlah view untuk melihat Order Details yang berisi OrderID, ProductID, ProductName, UnitPrice, Quantity, Discount, Harga setelah diskon.*/

CREATE VIEW SHOW_ORDER_DETAILS
AS
SELECT OrderID, Products.ProductID, Products.ProductName, [Order Details].UnitPrice, [Order Details].Quantity, [Order Details].Discount,[Order Details].UnitPrice - [Order Details].Discount as 'Price After Discount' FROM [Order Details] JOIN Products ON [Order Details].ProductID = Products.ProductID 

SELECT * FROM SHOW_ORDER_DETAILS

/*Buatlah procedure Invoice untuk memanggil CustomerID, CustomerName/company name, OrderID, OrderDate, RequiredDate, ShippedDate jika terdapat inputan CustomerID tertentu.*/
CREATE PROCEDURE Invoice @CustomerId nvarchar(30)
as
SELECT Customers.CustomerID, CompanyName, OrderID, OrderDate, RequiredDate, ShippedDate FROM Orders JOIN Customers ON Orders.CustomerID = Customers.CustomerID WHERE Customers.CustomerID = @CustomerId
GO

EXEC Invoice @CustomerId = 'ALFKI'

