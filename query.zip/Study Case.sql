/*Customer Analysis
Contoh : kita dapat menganalisis Recency, Frequency, dan Monetary (RFM) dalam setahun, kemudian dilakukan segmentasi dan actionable insight yang dapat dilakukan tiap segmen. */

/*Employee Analysis
Contoh : kita dapat menganalisis siapa dan title employee yang banyak berurusan dengan order.
*/

/*Product Analysis
Contoh : kita dapat menganalisa trend penjualan tiap bulan berdasarkan produknya, jenis customer, jenis produk, dan lain-lain.
*/


SELECT TOP 10 Customers.CustomerID, CompanyName, COUNT(Orders.OrderId) as 'Count Order' INTO Customer_Count_Order FROM Orders JOIN Customers ON Orders.CustomerID = Customers.CustomerID JOIN [Order Details] ON Orders.OrderID = [Order Details].OrderID WHERE YEAR(OrderDate) = 1997 GROUP BY Customers.CustomerID, CompanyName ORDER BY COUNT(Orders.OrderId) DESC

SELECT TOP 10 Customers.CustomerID, CompanyName, ROUND(SUM((UnitPrice * Quantity) - Discount),2) as 'Total Purchase' INTO Customer_Total_Purchase FROM Orders JOIN Customers ON Orders.CustomerID = Customers.CustomerID JOIN [Order Details] ON Orders.OrderID = [Order Details].OrderID WHERE YEAR(OrderDate) = 1997 GROUP BY Customers.CustomerID, CompanyName ORDER BY SUM((UnitPrice * Quantity) - Discount) DESC

SELECT ContactTitle, ROUND(SUM((UnitPrice * Quantity) - Discount),2) as 'Total Purchase' INTO Title_Total_Purchase FROM Orders JOIN Customers ON Orders.CustomerID = Customers.CustomerID JOIN [Order Details] ON Orders.OrderID = [Order Details].OrderID WHERE YEAR(OrderDate) = 1997 GROUP BY ContactTitle ORDER BY SUM((UnitPrice * Quantity) - Discount) DESC

SELECT ContactTitle, COUNT(Orders.OrderId) as 'Count Order' INTO Title_Count_Order FROM Orders JOIN Customers ON Orders.CustomerID = Customers.CustomerID JOIN [Order Details] ON Orders.OrderID = [Order Details].OrderID WHERE YEAR(OrderDate) = 1997 GROUP BY ContactTitle ORDER BY COUNT(Orders.OrderId) DESC

SELECT CONCAT(FirstName, ' ',LastName) as 'Employee Name' , COUNT(Orders.OrderId) as 'Count Order' INTO Employee_Count_Order FROM Orders JOIN Employees ON Orders.EmployeeID = Employees.EmployeeID  WHERE YEAR(OrderDate) = 1997 GROUP BY Employees.EmployeeID, FirstName, LastName ORDER BY COUNT(Orders.OrderId) DESC

SELECT Title , COUNT(Orders.OrderId) as 'Count Order' INTO Employee_Title_Count_Order FROM Orders JOIN Employees ON Orders.EmployeeID = Employees.EmployeeID  WHERE YEAR(OrderDate) = 1997 GROUP BY Title ORDER BY COUNT(Orders.OrderId) DESC

SELECT TOP 10 ProductName, COUNT(Orders.OrderId) as 'Count Order' INTO Product_Most_Order FROM Orders JOIN Customers ON Orders.CustomerID = Customers.CustomerID JOIN [Order Details] ON Orders.OrderID = [Order Details].OrderID JOIN Products ON [Order Details].ProductID = Products.ProductID WHERE YEAR(OrderDate) = 1997 GROUP BY ProductName ORDER BY COUNT(Orders.OrderId) DESC

SELECT TOP 10 ProductName, ROUND(SUM(([Order Details].UnitPrice * Quantity) - Discount),2) as 'Total Sales' INTO Product_Most_Sale  FROM Orders JOIN Customers ON Orders.CustomerID = Customers.CustomerID JOIN [Order Details] ON Orders.OrderID = [Order Details].OrderID JOIN Products ON [Order Details].ProductID = Products.ProductID WHERE YEAR(OrderDate) = 1997 GROUP BY ProductName ORDER BY SUM(([Order Details].UnitPrice * Quantity) - Discount) DESC

SELECT TOP 10 CategoryName,ROUND(SUM(([Order Details].UnitPrice * Quantity) - Discount),2) as 'Total Sales' INTO Categpory_Most_Order FROM Orders JOIN Customers ON Orders.CustomerID = Customers.CustomerID JOIN [Order Details] ON Orders.OrderID = [Order Details].OrderID JOIN Products ON [Order Details].ProductID = Products.ProductID JOIN Categories ON Products.CategoryID = Categories.CategoryID WHERE YEAR(OrderDate) = 1997 GROUP BY CategoryName ORDER BY SUM(([Order Details].UnitPrice * Quantity) - Discount) DESC

SELECT TOP 10 CategoryName, COUNT(Orders.OrderId) as 'Count Order'  INTO Categpory_Most_Sales FROM Orders JOIN Customers ON Orders.CustomerID = Customers.CustomerID JOIN [Order Details] ON Orders.OrderID = [Order Details].OrderID JOIN Products ON [Order Details].ProductID = Products.ProductID JOIN Categories ON Products.CategoryID = Categories.CategoryID WHERE YEAR(OrderDate) = 1997 GROUP BY CategoryName ORDER BY COUNT(Orders.OrderId) DESC